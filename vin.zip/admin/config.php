<?php
// HTTP
define('HTTP_SERVER', 'http://vinsantehnik.com.ua/admin/');
define('HTTP_CATALOG', 'http://vinsantehnik.com.ua/');

// HTTPS
define('HTTPS_SERVER', 'http://vinsantehnik.com.ua/admin/');
define('HTTPS_CATALOG', 'http://vinsantehnik.com.ua/');

// DIR
define('DIR_APPLICATION', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/admin/');
define('DIR_SYSTEM', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/');
define('DIR_LANGUAGE', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/admin/language/');
define('DIR_TEMPLATE', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/admin/view/template/');
define('DIR_CONFIG', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/config/');
define('DIR_IMAGE', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/image/');
define('DIR_CACHE', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/storage/cache/');
define('DIR_DOWNLOAD', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/storage/download/');
define('DIR_LOGS', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/storage/logs/');
define('DIR_MODIFICATION', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/storage/modification/');
define('DIR_UPLOAD', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/system/storage/upload/');
define('DIR_CATALOG', 'D:/WebServer/OpenServer/domains/vinsantehnik.com.ua/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'vinsantehnick');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
